import os
import json
import re
from datetime import datetime
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# In-memory store: suitable for a college demo. Replace with SQLite/PostgreSQL for production.
activities = []


def clean_text(value, limit=3000):
    return str(value or "").strip()[:limit]


def local_answer(question):
    q = question.lower()
    bank = {
        "machine learning": "Machine Learning is a branch of AI where systems learn patterns from data to make predictions or decisions. The three common types are supervised, unsupervised, and reinforcement learning. Example: a model can learn from past marks to predict performance.",
        "python": "Python is a high-level, interpreted programming language known for readable syntax. It is widely used in AI, data science, automation, web development, and scripting.",
        "dbms": "A DBMS is software used to store, organize, retrieve, and manage data. Important concepts include tables, keys, SQL, normalization, transactions, and constraints.",
        "oops": "Object-Oriented Programming organizes software using classes and objects. The four major concepts are encapsulation, abstraction, inheritance, and polymorphism.",
        "artificial intelligence": "Artificial Intelligence is the field of computing concerned with building systems that perform tasks associated with human intelligence, such as learning, reasoning, perception, and language understanding.",
        "binary search": "Binary search works on a sorted array by repeatedly checking the middle element and eliminating half of the remaining search space. Its time complexity is O(log n)."
    }
    for key, value in bank.items():
        if key in q:
            return value
    return (f"Study explanation for: {question}\n\n"
            "1. Understand the definition.\n"
            "2. Learn the main concepts and working.\n"
            "3. Study one small example.\n"
            "4. Practice 5 questions.\n"
            "5. Revise the mistakes before the next quiz.")


def openai_call(instructions, prompt):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-5-mini"),
            instructions=instructions,
            input=prompt,
        )
        return response.output_text.strip()
    except Exception:
        return None


def ai_answer(question):
    result = openai_call(
        "You are EduAI, a college study assistant. Explain concepts accurately in simple student-friendly language. Use headings, short examples, and exam points where useful. Do not invent facts.",
        question,
    )
    return result or local_answer(question)


def local_quiz(subject, topic, count):
    templates = [
        {
            "question": f"Which statement best describes {topic} in {subject}?",
            "options": ["A core concept used to understand the topic", "A type of computer hardware", "A network cable", "An operating system"],
            "answer": 0,
            "explanation": f"The first option is the most appropriate general description of {topic}."
        },
        {
            "question": f"What is a good first step when learning {topic}?",
            "options": ["Understand the definition and basic idea", "Skip theory completely", "Memorize random code", "Avoid examples"],
            "answer": 0,
            "explanation": "Understanding the basic idea makes later examples and problem solving easier."
        },
        {
            "question": f"Which activity is most useful for improving knowledge of {topic}?",
            "options": ["Practice questions and review mistakes", "Never revise", "Only read the title", "Avoid problem solving"],
            "answer": 0,
            "explanation": "Practice followed by error review improves understanding and retention."
        },
        {
            "question": f"For an exam, which approach is strongest for {topic}?",
            "options": ["Definition + concept + example + practice", "Only memorize one sentence", "Skip difficult questions", "Study without revision"],
            "answer": 0,
            "explanation": "Combining concepts, examples, and practice is a balanced exam strategy."
        },
    ]
    return (templates * ((count + len(templates) - 1) // len(templates)))[:count]


def generate_quiz(subject, topic, count):
    prompt = f"Create exactly {count} multiple-choice questions for a college student. Subject: {subject}. Topic: {topic}. Return ONLY valid JSON as an array. Each object must contain question, options (exactly 4 strings), answer (0-3 integer), and explanation. Keep questions educational and unambiguous."
    raw = openai_call("You are an AI quiz generator. Output strict JSON only.", prompt)
    if raw:
        try:
            cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.I)
            data = json.loads(cleaned)
            if isinstance(data, list) and data:
                return data[:count]
        except Exception:
            pass
    return local_quiz(subject, topic, count)


def recommendation(score):
    if score >= 90:
        return "Excellent! Move to advanced problems, timed practice, and teach the concept to someone else."
    if score >= 75:
        return "Good performance. Revise weak points and solve 5–10 higher-difficulty questions."
    if score >= 50:
        return "You are progressing. Review fundamentals, make short notes, and practice daily."
    return "Start with the basics. Relearn key concepts, study worked examples, and retake a short quiz."


@app.get("/")
def home():
    scores = [x["score"] for x in activities if x.get("type") == "quiz"]
    avg = round(sum(scores) / len(scores), 1) if scores else 0
    return render_template("index.html", statistics={
        "total": len(activities),
        "average": avg,
        "quizzes": len(scores),
        "questions": sum(1 for x in activities if x.get("type") == "question"),
    })


@app.post("/api/ask")
def ask():
    data = request.get_json(silent=True) or {}
    question = clean_text(data.get("question"))
    if not question:
        return jsonify({"error": "Question is required."}), 400
    answer = ai_answer(question)
    activities.append({"type": "question", "question": question, "time": datetime.now().isoformat(timespec="seconds")})
    return jsonify({"answer": answer})


@app.post("/api/quiz")
def quiz():
    data = request.get_json(silent=True) or {}
    subject = clean_text(data.get("subject"), 100) or "Computer Science"
    topic = clean_text(data.get("topic"), 200) or "General Concepts"
    try:
        count = max(3, min(10, int(data.get("count", 5))))
    except (TypeError, ValueError):
        count = 5
    questions = generate_quiz(subject, topic, count)
    return jsonify({"subject": subject, "topic": topic, "questions": questions})


@app.post("/api/quiz/submit")
def submit_quiz():
    data = request.get_json(silent=True) or {}
    questions = data.get("questions", [])
    selected = data.get("answers", [])
    if not questions:
        return jsonify({"error": "No quiz submitted."}), 400
    correct = 0
    for i, q in enumerate(questions):
        if i < len(selected) and selected[i] == q.get("answer"):
            correct += 1
    score = round(correct / len(questions) * 100, 1)
    advice = recommendation(score)
    activities.append({"type": "quiz", "score": score, "correct": correct, "total": len(questions), "time": datetime.now().isoformat(timespec="seconds")})
    return jsonify({"score": score, "correct": correct, "total": len(questions), "recommendation": advice})


@app.post("/api/recommend")
def recommend_api():
    data = request.get_json(silent=True) or {}
    try:
        score = float(data.get("score"))
    except (TypeError, ValueError):
        return jsonify({"error": "Enter a valid score."}), 400
    if not 0 <= score <= 100:
        return jsonify({"error": "Score must be between 0 and 100."}), 400
    return jsonify({"score": score, "recommendation": recommendation(score)})


@app.get("/api/progress")
def progress():
    return jsonify({"activities": activities[-20:]})


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "ai_mode": "OpenAI" if os.getenv("OPENAI_API_KEY") else "Demo fallback"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=True)
