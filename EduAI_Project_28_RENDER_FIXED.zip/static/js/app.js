async function postJSON(url, body) {
  const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function askAI(){
  const q=document.getElementById('question').value.trim(), box=document.getElementById('answer');
  if(!q){box.textContent='Please enter a question first.';return;}
  box.textContent='EduAI is thinking...';
  try{const d=await postJSON('/api/ask',{question:q}); box.textContent=d.answer;}
  catch(e){box.textContent=e.message;}
}

let currentQuiz=[];
async function generateQuiz(){
  const subject=document.getElementById('subject').value.trim()||'Computer Science';
  const topic=document.getElementById('topic').value.trim()||'General Concepts';
  const count=Number(document.getElementById('count').value);
  const box=document.getElementById('quizBox'); box.innerHTML='<div class="output">Generating AI questions...</div>';
  try{
    const d=await postJSON('/api/quiz',{subject,topic,count}); currentQuiz=d.questions;
    box.innerHTML=currentQuiz.map((q,i)=>`<div class="question"><h3>${i+1}. ${escapeHTML(q.question)}</h3>${q.options.map((o,j)=>`<label><input type="radio" name="q${i}" value="${j}"> ${escapeHTML(o)}</label>`).join('')}</div>`).join('')+'<button onclick="submitQuiz()">Submit Quiz ✓</button><div id="quizResult"></div>';
  }catch(e){box.innerHTML='<div class="output">'+escapeHTML(e.message)+'</div>';}
}
async function submitQuiz(){
  const answers=currentQuiz.map((_,i)=>{const el=document.querySelector(`input[name=q${i}]:checked`); return el?Number(el.value):-1;});
  const result=document.getElementById('quizResult');
  try{const d=await postJSON('/api/quiz/submit',{questions:currentQuiz,answers}); result.className='output'; result.innerHTML=`<strong>Score: ${d.score}%</strong><br>${d.correct}/${d.total} correct.<br>${escapeHTML(d.recommendation)}`;}
  catch(e){result.textContent=e.message;}
}
async function recommend(){
  const score=document.getElementById('score').value, box=document.getElementById('recommendation');
  if(score===''){box.textContent='Please enter a score between 0 and 100.';return;}
  try{const d=await postJSON('/api/recommend',{score:Number(score)}); box.innerHTML=`<strong>${d.score}%</strong><br>${escapeHTML(d.recommendation)}`;}catch(e){box.textContent=e.message;}
}
function escapeHTML(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
