# Project Overview

## Title
EduAI — AI-Powered Personal Study Assistant

## Objective
Provide students with an intelligent learning companion for question answering, quiz generation, scoring, and personalized study recommendations.

## Core workflow
Student -> Web Dashboard -> Flask API -> AI Model -> Response/Quiz -> Score -> Recommendation

## Technologies
HTML5, CSS3, JavaScript, Python, Flask, OpenAI API, REST API.

## Future scope
Database persistence, login, PDF notes/RAG, subject-wise analytics, voice interaction, and teacher dashboard.
